python3.6 -m venv venv
source venv/bin/activate
export PYTHONPATH=.:$PYTHONPATH
